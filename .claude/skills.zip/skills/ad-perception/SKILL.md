---
name: ad-perception
description: 深信服 AD 设备感知分析技能，支持流量3σ异常检测、设备状态阈值告警、IP:Port地址冲突检测和日志线索关联。当用户提到"感知分析"、"异常检测"、"流量分析"、"状态告警"、"冲突检测"、"日志关联"时触发。
---

# AD 感知分析

AD 设备感知分析技能，提供 VS 流量趋势异常检测、设备状态阈值判定、地址冲突检测和日志线索关联。

## 功能概述

| 功能 | 说明 |
|------|------|
| 采集器守护进程 | 60s 采样 VS 指标落 SQLite |
| 流量趋势分析 | 3σ 异常检测（需采集器累积数据） |
| 设备状态分析 | CPU/内存/风扇/电源/接口阈值判定 |
| 地址冲突检测 | VS IP:Port 重叠 + Pool 节点重复 |
| 日志线索 | 异常事件 ± 5min 服务日志关联 |

## CLI 命令参考

```bash
# 采集器（常驻后台）
python scripts/collector.py --host https://x.x.x.x --user admin --password xxx [--db vs_samples.db] [--interval 60]

# 全维度感知分析
python scripts/perception.py analyze --host https://x.x.x.x [--db vs_samples.db] [--format json]

# 单维度
python scripts/perception.py traffic --host ... --vs <name> [--db ...] [--format json]
python scripts/perception.py state --host ... [--disk-source check_report_dir] [--format json]
python scripts/perception.py conflict --host ... [--format json]
```

## 执行工作流

```
┌─ 采集器 ─────────────────────────────────────────┐
│ python scripts/collector.py --host ...             │
│  → 首次启动: 建表                                 │
│  → 每 60s: get_vs_stat → INSERT                  │
│  → 保持运行（建议 Windows 任务计划 / systemd）     │
└──────────────────────────────────────────────────┘

┌─ 感知分析 ───────────────────────────────────────┐
│ python scripts/perception.py analyze --host ...    │
│  1. 流量: SQLite → 3σ 或 API 兜底                 │
│  2. 状态: get_sys_system + --disk-source          │
│  3. 日志: get_service_log (如有异常)               │
│  4. 冲突: get_vs × get_pools                      │
│  → render_markdown() → stdout                     │
└──────────────────────────────────────────────────┘
```

## 脚本强制规则

| 操作 | 必须使用 | 禁止使用 |
|------|----------|----------|
| 总览快照 | `python scripts/overview.py` | ❌ ad-ops 直调 API |
| 启动采集器 | `python scripts/collector.py` | ❌ 手动 HTTP 请求 |
| 感知分析 | `python scripts/perception.py analyze/traffic/state/conflict` | ❌ LLM 直调 API |
| 展示报告 | 脚本 stdout 原样贴入对话 | ❌ LLM 修改/总结/补全 |

## 已知设备

| 设备 | IP | 用户 |
|------|-----|------|
| AD1 (21039) | 14.18.243.211:21039 | admin |
| AD2 (21044) | 14.18.243.211:21044 | admin |
| AD1 (旧) | 10.146.10.254 | admin |

> 密码通过 `--password` 或环境变量 `AD_PASS` 传入，不写入文件。

## 行为准则

### 必须行为
- ✅ 所有分析通过 `scripts/perception.py` / `scripts/collector.py` 脚本
- ✅ 报告内容由脚本 `render_markdown()` 直接产出，LLM 原样展示
- ✅ 采集器未启动或数据不足 → 脚本在输出中明确告知，LLM 转述

### 禁止行为
- ❌ LLM 直调 AD API
- ❌ LLM 分析、推断、判断异常
- ❌ LLM 修改脚本输出内容
- ❌ 混合其他 API 结果补充报告
- ❌ LLM "善意补救" 部分失败（exit 5 表示部分失败，应如实告知用户）
- ❌ 在会话中途运行 `ad-check-analysis` 来补充磁盘数据（应提示用户先跑巡检，然后用 `--disk-source` 传入）

## 报告展示规则

**必须将脚本 stdout 内容直接展示在对话消息正文中**，不要放在 shell 执行结果的折叠区域中。

## 外部依赖

| 依赖 | 说明 |
|------|------|
| `scripts/ad_api.py` | 提供 `ADClient`（API 调用），import 失败 exit 9 |
| `ad-check-analysis` 巡检报告 | `perception.py state --disk-source` 需要 ad.json 中的 `disk_check`。**未提供时脚本标注缺失，不阻止其余分析** |
| SSL 证书 | `ADClient` 禁用 TLS 验证（`CERT_NONE`），仅适用于内网自签名环境 |
| 采集器累积时间 | 首次启动后需累积 ≥ 100 个采样点（约 2h）才能跑 3σ |

## 错误码

| 场景 | exit code |
|------|----------|
| 完全成功 | 0 |
| 连接失败 | 1 |
| 全部 API 失败 | 1 |
| 认证失败 | 2 |
| SQLite 写入失败 | 3 |
| 参数错误 | 4 |
| 部分失败（其余正常） | 5 |
| 采集器重复启动 | 6 |
| ADClient import 失败 | 9 |

## 相关技能

- **ad-ops**: AD 智能运维（API 调用、设备管理），本技能通过 import 复用其 `ADClient`
- **ad-check-analysis**: AD 系统巡检，本技能 `--disk-source` 可摄入其巡检报告中的磁盘数据
- **ad-blackbox-analysis**: AD 黑盒日志分析，P0 不使用，P1 可用于深度根因
